# Spectrum shared-input qualification

Result: 90 scenarios passed normally and with AddressSanitizer/UndefinedBehaviorSanitizer (180 workflow executions). All 18 sampled non-keyboard views are pixel-identical to the original app in both builds (36 comparisons). All 276 captured images match between normal and sanitizer builds. Two contact sheets were inspected visually.

## What ran

The actual Spectrum `app_main`, actual production PortableApps adapter, and the published scene-host, text-input, and presentation-profile providers execute together. Deterministic fixtures provide display custody/completion, ordered raw touch, navigation, microphone PCM, KV/app-data storage, RTC, battery, alarm, BLE/Wi-Fi controls, and a bounded base Contexts service. No app controller or keyboard is replaced by a mock.

All four editor entrypoints are covered: frequency label, signature sample, temporal-event name, and shared context-signal name. Every session requests capacity 17, preserving 16 printable ASCII characters plus NUL. Tests cover Done without persistence, Cancel, header Back/Home, hardware Back/Home, three-session reopening, over-capacity rejection, mixed ASCII, real crown/navigation focus, rapid repeat typing, delayed presentation, acquisition unavailable for every keyboard frame, and continued microphone/analysis progress. Explicit-save tests distinguish label/event persistence from starting signature/shared training. Additional cases complete and verify the real 100-window signature capture and 32-second shared-room training save.

Four `ui-*` cases navigate entirely by touch from the normal startup screen, then edit and save/start/cancel through the production UI. Frequency and temporal saved names are reopened. Boundary/fault scenarios establish editor preconditions using production entrypoints; the non-keyboard raster cases establish deterministic screen state. These setup actions are disclosed rather than represented as touch navigation.

Fault coverage includes absent and undersized host APIs, open rejection, failed subsequent acquisition, recovery into another editor without shared-editor flag contamination, runtime loss during open/poll/close, and an unconfirmed host unsubscribe that forces retained invocation custody. Retained cases assert no subsequent provider I/O or launch, unchanged owned resources, and refused module reentry. Clean cases assert zero remaining grants, subscriptions, frame leases, tokens, microphone ownership, and wrapped allocations. Every screenshot checks RGB565 stride guards.

## Pins

- Tested production app commit: `82d17d0d902d427938af95aae0e976c8f78041ed`
- Published tree: `d3ac32ebb70b52771360fa30e3f067fdb8f2e0e7`
- Test source is included in that same published commit
- System: `7fb13b09b4dac275a8111b224784f8a472f39264`
- Runtime SDK: `64c8e52e46fd91e8fdafd636db04eed88f0c51a9`
- Original Utilities baseline: `e85eff650e9f748ae162fb725fb6e14eb6df876a`
- Deployed feature recipe: `/workspace/shared/watch-scroll-regression-20261011/watch-1110-public-source-build/clients.json`, `audio_spectrum`

All original `-D` feature selections and the frozen full catalog are preserved. Added flags match the selected Watch target: text client, Spectrum shared input, checked storage, native custody fence, alarm terminal retention, launch guard, Watch color-only and frozen icons. No text-face subset is selected. Native qualification substitutes native C compilation for target architecture/linker/code-generation options only. Exact inputs and hashes are in `qualification.json` and the compile-command records.

## Evidence

This is the complete rerun from the published source, rather than a receipt relabeled from the earlier local execution. Original and published app/harness input hashes were verified equal.

- `qualification.json`: input hashes, pins, every scenario result, comparisons, limitations
- `normal/` and `sanitized/`: action scripts, complete run logs, individual PNGs
- `editor-contact-sheet.png`: shared keyboards, accepted editor drafts, and 16-character limits for all four editors
- `non-keyboard-contact-sheet.png`: 18 unchanged views, including all 12 non-keyboard page kinds and main-screen variants
- `normal/baseline-non-keyboard-views/`, `sanitized/baseline-non-keyboard-views/`: original-app reference captures

Example delayed-close result: audio reads advanced from 92 to 203 and completed analysis transforms from 46 to 101 during 111 close-AGAIN iterations, with a three-second pending keyboard display. Input and capture remained independent of final presentation completion.

## Reproduce

From `/workspace/shared/spectrum-shared-input-utilities-published-20261012`, the clean verified published checkout:

```sh
python scripts/test_spectrum_shared_input.py \
  --system-apps /workspace/shared/lora-long-text-system-published-20261012 \
  --runtime /workspace/shared/watch-runtime-file-source-20261012 \
  --baseline-utilities /workspace/shared/lora-shared-input-utilities-published-20261012 \
  --output /workspace/shared/spectrum-shared-input-evidence-20261012/workflow
```

## Limits

This is synthetic native qualification, not a microphone, PMU/sleep, physical crown, RF, target-instruction or hardware deployment test. The Contexts fingerprint suffix is absent in the fixture; the app-local shared fingerprint pipeline and serialized app-data are real. LeakSanitizer is disabled for the executor's ptrace limitation; AddressSanitizer and UndefinedBehaviorSanitizer are enabled and explicit ownership/allocation counters remain active. Target build, Runtime cohort admission, and release publication are separate qualifications.
