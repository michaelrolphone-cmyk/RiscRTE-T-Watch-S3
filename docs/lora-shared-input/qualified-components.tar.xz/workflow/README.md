# Final published-source LoRa shared-input qualification

PASS: 29 production workflows, normal and ASan/UBSan (58 successful runs). All final recorded source hashes match the checked working files. No production app defect found.

## Exact tested sources

- Utilities: e85eff650e9f748ae162fb725fb6e14eb6df876a
- System: 7fb13b09b4dac275a8111b224784f8a472f39264
- Watch Runtime SDK: 64c8e52e46fd91e8fdafd636db04eed88f0c51a9

source-pins.json records paths and working-tree status. qualification.json records every deployment define, added safety selector, three final size selectors, source hashes and all run results.

## Reproduction

From /workspace/shared/lora-shared-input-utilities-published-20261012:

    python3 scripts/test_lora_shared_input.py --system-apps /workspace/shared/lora-long-text-system-published-20261012 --runtime /workspace/shared/watch-runtime-file-source-20261012 --extra-define PORTABLE_WATCH_COLOR_ONLY --extra-define PORTABLE_WATCH_FROZEN_ICONS --extra-define PORTABLE_NOVA_TEXT_FACES_012 --output /workspace/shared/lora-shared-input-evidence-20261012/final-workflow

## Results

Actual app_main, Portable adapter, Watch-compact scene host, text-input host and profile provider execute all workflows. The production LoRa source and C fixture are unchanged from the earlier qualification. The app is included verbatim only to allow state observation; the text proxy records real requests/results and provides explicit failure injection.

Coverage includes 240-byte accept/reopen/send/history, all six 11-byte RF input limits, six valid RF edits, invalid RF preserved help/Edit recovery and Back discard, accepted-draft preservation on Cancel, missing/old host and reopen, explicit Send versus Done, successful and canceled-send history, active listening across editing, header and navigation Home/Back, delayed frame and close retries, 24 rapid keys with pending draw, refused cleanup and runtime-loss retention, frozen retained allocations/resources, and no provider I/O after retention. All clean exits have zero live grants, frames, touch subscriptions and production malloc allocations.

## Visual parity

All 25 retained screenshots are pixel-identical to the earlier qualification of the identical app source without the three Watch size selectors. All 17 non-editor views are unchanged. visual-comparison.json records each comparison. visual-review.png is the reviewed 8-panel, 24-KB contact sheet; native PNGs are retained under normal/. No accumulating PPM frame dumps are retained.

## Boundaries

Physical RF, display/touch/PMU, storage, alarm, clock/battery, BLE and Wi-Fi controls remain deterministic fixture backends. Contexts uses its supported clean-unavailable path. This qualifies native app/controller/presenter behavior; it does not claim physical Watch deployment, RF-over-air, USB-keyboard, PMU/sleep, or ELF-loader integration. All deployed -D flags were preserved. Native compilation substitutes -O1 -g for Xtensa-specific build/link/LTO options and uses the selected SDK alarm helper instead of the historical compatibility shim.

LeakSanitizer is unavailable in this executor (fatal ptrace/runtime error even on idle). ASan/UBSan therefore use detect_leaks=0; independent linker-level malloc/free tracking proves clean exits free all production allocations and retained paths preserve their allocation count.
