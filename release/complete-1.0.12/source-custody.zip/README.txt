Watch 1.0.12 delivered-image source and proof custody

Delivered full initial image:
  twatch-s3-1.0.12-FULL-INITIAL-ERASES-DATA-bma423.bin
  16,777,216 bytes
  SHA256 af958e480a3183bde3f448e97930d56b9aeea567a664428892b917a878d014ff

The full image is a 0x0 initial flash and erases settings, bonds, alarms, Points,
app-data and both banks. This archive is evidence and source custody, not a
flashable image or a release. The separate paired update payload has SHA256
9fdfaed08238524baec6524fe8915e03f9f5b0c8011f9c5b0027dc530629c2f4;
never flash that paired payload at zero. No updater catalog route was published.

All 22 prior apps remain. Native realtime, checked retained deep-wake resume,
demand startup/promotion, awake-background BLE telemetry, and the SDR/audio
capture-active idle behavior are included. Current Watch telemetry exposes
battery percentage, voltage and charging; no temperature source is invented.
Broadcasting respects Bluetooth/Airplane/low-battery controls and pauses for
sleep and foreground scanner/HID/SDR use. Raw SDR requires Bluetooth off.
Generic file-open is inapplicable to the current read-only installed-files
browser: no SD source or declared compatible receiver is installed.

The exact accepted Watch 1.0.11 origin is retained. Paired-update host proofs
passed both ordinary and ASan/UBSan modes, each with 31 scenarios, 159 fresh
process transactions and 16 negative admissions. Actual full-store Clock
host execution passed 8 cases in both modes. All 17 related hosted workflows
passed at the exact heads recorded in hosted-ci.json. Host tests do not execute
Xtensa instructions or establish physical sleep, RF reception or power results.
Watch 1.0.12 hardware acceptance remains for the owner's test.

source-equivalence.json preserves the original local commit identities used by
the delivered build, and their exact public tree equivalents. Public PRs:
  https://github.com/michaelrolphone-cmyk/RiscRTE-T-Watch-S3/pull/48
  https://github.com/michaelrolphone-cmyk/RiscRTE-System-Apps/pull/76
  https://github.com/michaelrolphone-cmyk/RiscRTE-Utilities/pull/47
  https://github.com/michaelrolphone-cmyk/RiscRTE-Productivity/pull/16
  https://github.com/michaelrolphone-cmyk/RiscRTE/pull/45

Incremental Git bundles in sources/ preserve the exact local build commits.
Each bundle requires the public prerequisite commit listed in the mapping.
In a clone of the named repository, fetch that prerequisite and its ancestors,
then run git bundle verify on the bundle, git fetch <bundle> HEAD, and create a
separate worktree at the mapped built_commit. Bundles were locally verified.
Generic Drivers remains public 4088b6892c2e2654b0342f04a7d191068e4a8e2e.
Compiler: Xtensa ESP32-S3 GCC 8.4.0. Native firmware was reused byte-exact from
the qualified Runtime 0.1.55 build; native-custody.json records all inputs.
A remote-only reconstruction using mapped public commits must record fresh
build provenance. Never change the provenance labels of the delivered image.

proof/SHA256SUMS describes the separate complete candidate directory, including
binary files not duplicated in this source/proof archive. ARCHIVE-SHA256SUMS
checks all files actually included here. No merge or release was performed.
